/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.sistemaPraia.telas;

/**
 *
 * @author PC
 */
import java.sql.*;
import br.com.sistemaPraia.dal.Conexao;
import java.text.DateFormat;
 import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
public class TelaAcampar extends javax.swing.JInternalFrame {

    /**
     * Creates new form TelaAcampar
     */
    
    Connection conexao= null;
    PreparedStatement pst= null;
     ResultSet rs = null;
    public TelaAcampar() {
        conexao= Conexao.Conector();
        initComponents();
    }

         
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Nuacamp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        DataAcamp = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Situ = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        AreaAcamp = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        DiasAcampado = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        VTotal = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        ValorDia = new javax.swing.JTextField();
        Calcular = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        DataRegistroAcampa = new javax.swing.JFormattedTextField();
        jPanel2 = new javax.swing.JPanel();
        PesquisaCamp = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TblAcamp = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        IdCamp = new javax.swing.JTextField();
        BotaoSalvar = new javax.swing.JButton();
        BotaPesquisar = new javax.swing.JButton();
        BotaEditar = new javax.swing.JButton();
        BotaExcluir = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        OB = new javax.swing.JTextArea();
        BotaImprime = new javax.swing.JButton();

        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Tela Acampar");
        setPreferredSize(new java.awt.Dimension(640, 480));

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setText("Nº Acampamento");

        Nuacamp.setEnabled(false);

        jLabel2.setText("Data");

        DataAcamp.setEnabled(false);

        jLabel3.setText("Situação Acamp");

        Situ.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Uso", "Reservador", "Manutenção" }));
        Situ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SituActionPerformed(evt);
            }
        });

        jLabel6.setText("Area Acampamento");

        jLabel7.setText("Dias Acampado");

        jLabel8.setText("Valor Total");

        jLabel9.setText("Valor Dia");

        Calcular.setForeground(new java.awt.Color(255, 0, 51));
        Calcular.setText("Calcular");

        jLabel11.setText("Data Inicio Acampamento");

        DataRegistroAcampa.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DiasAcampado)
                    .addComponent(VTotal)
                    .addComponent(ValorDia))
                .addGap(20, 20, 20))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                        .addComponent(Situ, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DataRegistroAcampa))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(36, 36, 36)
                                .addComponent(AreaAcamp)))
                        .addGap(10, 10, 10)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Nuacamp))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(DataAcamp, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Calcular)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Nuacamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DataAcamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Situ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(DataRegistroAcampa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel6))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AreaAcamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(DiasAcampado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(16, 16, 16))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(ValorDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(VTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(Calcular)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Campista"));

        PesquisaCamp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                PesquisaCampKeyReleased(evt);
            }
        });

        jLabel4.setText("Pesquisar ");

        TblAcamp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nome", "CPF", "Fone", "ID", "OB"
            }
        ));
        TblAcamp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TblAcampMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TblAcamp);

        jLabel5.setText("*ID");

        IdCamp.setEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PesquisaCamp, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(IdCamp, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 21, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PesquisaCamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(IdCamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        BotaoSalvar.setForeground(new java.awt.Color(51, 51, 51));
        BotaoSalvar.setText("Salvar");
        BotaoSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoSalvarActionPerformed(evt);
            }
        });

        BotaPesquisar.setText("Pesquisar");

        BotaEditar.setText("Editar");

        BotaExcluir.setText("Excluir");

        jLabel10.setText("Observações");

        OB.setColumns(20);
        OB.setRows(5);
        jScrollPane2.setViewportView(OB);

        BotaImprime.setText("Imprime");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(92, Short.MAX_VALUE)
                .addComponent(BotaoSalvar)
                .addGap(30, 30, 30)
                .addComponent(BotaPesquisar)
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BotaEditar)
                        .addGap(29, 29, 29)
                        .addComponent(BotaExcluir)
                        .addGap(18, 18, 18)
                        .addComponent(BotaImprime, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel10)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(75, 75, 75))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {BotaEditar, BotaExcluir, BotaImprime, BotaPesquisar, BotaoSalvar});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BotaoSalvar)
                            .addComponent(BotaPesquisar)
                            .addComponent(BotaEditar)
                            .addComponent(BotaExcluir)
                            .addComponent(BotaImprime))))
                .addContainerGap(77, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {BotaEditar, BotaExcluir, BotaImprime, BotaPesquisar, BotaoSalvar});

        setBounds(0, 0, 731, 448);
    }// </editor-fold>//GEN-END:initComponents

    private void SituActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SituActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SituActionPerformed

    private void PesquisaCampKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PesquisaCampKeyReleased
        // TODO add your handling code here:
        PesquisarCampistas();
    }//GEN-LAST:event_PesquisaCampKeyReleased

    private void TblAcampMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TblAcampMouseClicked
        // TODO add your handling code here:
        
        setar_campos();
    }//GEN-LAST:event_TblAcampMouseClicked

    private void BotaoSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoSalvarActionPerformed
        // TODO add your handling code here:
        EmitirAcampamento();
    }//GEN-LAST:event_BotaoSalvarActionPerformed

private void PesquisarCampistas(){
    String sql = " select idCamp as ID, NomeCamp as Nome, CpfCamp as CPF, TelefoneCamp as Fone,\n" +
"observacoes as OB from tbcampista where NomeCamp like ?";
    try {
        pst=conexao.prepareStatement(sql);
        // Passando da caixa de pesquisa
        pst.setString(1, PesquisaCamp.getText()+ "%");
        // executa a query
        rs=pst.executeQuery();
        // usa a biblioteca para preencher a tabela
        TblAcamp.setModel(DbUtils.resultSetToTableModel(rs));  
        
        
    } catch (Exception e) {
        JOptionPane.showInternalMessageDialog(null, e);
    }
}
 public void setar_campos(){
    
     int setar = TblAcamp.getSelectedRow();
     IdCamp.setText(TblAcamp.getModel().getValueAt(setar,0).toString());
     
    //BotaoSalvar.setEnabled(false);
    
    
    }    

// cadastrar acampamento
 
 private void EmitirAcampamento(){
 String sql= "insert into tbacampar(DataRegistroAcampa,Situacao,AreaAcamp,ObsAcamp,Atendente,valor,DiasAcamp,Idcamp) values(?,?,?,?,?,?,?,?)";
 
     try {
         
        pst=conexao.prepareCall(sql);
        String dia=DataRegistroAcampa.getText().substring(0, 2);
        String mes=DataRegistroAcampa.getText().substring(3,5);
        String ano=DataRegistroAcampa.getText().substring(6);
        String DataParaBanco=ano+"-"+mes+"-"+dia;
        
       pst.setString(1,DataParaBanco);
        pst.setString(2,Situ.getSelectedItem().toString());
         
        pst.setString(3, AreaAcamp.getText());
        pst.setString(4, DiasAcampado.getText());
       pst.setString(5, TelaPrincipal.atendente.getText());
        pst.setString(6, VTotal.getText());
        pst.setString(7, OB.getText());
        pst.setString(8,IdCamp.getText());
        
         if(((IdCamp.getText().isEmpty())||(DataParaBanco.isEmpty()))) {
              JOptionPane.showMessageDialog(null," Todos os Campos Marcados com *, são Obrigatórios");          
              
              
              
             
         } else {             
             
             int adicionado = pst.executeUpdate();
             if(adicionado >0){
               JOptionPane.showMessageDialog(null," Ordem de Acampamento Adicionado com Sucesso!!"); 
             
             Situ.setSelectedItem(null);
             AreaAcamp.setText(null);
             DiasAcampado.setText(null);
             TelaPrincipal.atendente.setText(null);
             VTotal.setText(null);
             OB.setText(null);
             IdCamp.setText(null);
             DataRegistroAcampa.setText(null);
             
             
             
             }
         }
        
        
        
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
     }
 
 
 
 
 
 
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AreaAcamp;
    private javax.swing.JButton BotaEditar;
    private javax.swing.JButton BotaExcluir;
    private javax.swing.JButton BotaImprime;
    private javax.swing.JButton BotaPesquisar;
    private javax.swing.JButton BotaoSalvar;
    private javax.swing.JButton Calcular;
    private javax.swing.JTextField DataAcamp;
    private javax.swing.JFormattedTextField DataRegistroAcampa;
    private javax.swing.JTextField DiasAcampado;
    private javax.swing.JTextField IdCamp;
    private javax.swing.JTextField Nuacamp;
    private javax.swing.JTextArea OB;
    private javax.swing.JTextField PesquisaCamp;
    private javax.swing.JComboBox<String> Situ;
    private javax.swing.JTable TblAcamp;
    private javax.swing.JTextField VTotal;
    private javax.swing.JTextField ValorDia;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
