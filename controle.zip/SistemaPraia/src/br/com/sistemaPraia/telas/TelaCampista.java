/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.sistemaPraia.telas;

import br.com.sistemaPraia.dal.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author PC
 */
public class TelaCampista extends javax.swing.JInternalFrame {
Connection conexao= null;
    PreparedStatement pst= null;
     ResultSet rs = null;
    /**
     * Creates new form TelaCampista
     */
    public TelaCampista() {
        conexao= Conexao.Conector();
        initComponents();
    }
    private void Adicionar(){
String sql = "insert into tbcampista(nomecamp,endcamp,TelefoneCamp,cpfcamp,PlacaCamp,observacoes)"
        + " values(?,?,?,?,?,?"
        + ")";

    try {
        pst=conexao.prepareStatement(sql);
        pst.setString(1,txtNomeCamp.getText() );
        pst.setString(2,txtEndeCamp.getText());
        pst.setString(3,txtfonecam.getText());
        pst.setString(4,txtCpfCamp.getText());
        pst.setString(5,TxtPlaca.getText());
        pst.setString(6,jObervacoes.getText());
        if(((txtNomeCamp.getText().isEmpty())||(txtCpfCamp.getText().isEmpty()))){        
        JOptionPane.showMessageDialog(null," Todos os Campos Marcados com *, são Obrigatórios");       
        
        }else{
        
        int adicionado = pst.executeUpdate();
        
        if(adicionado > 0){
        JOptionPane.showMessageDialog(null,"Campista  Cadastrado com Sucesso!!!");
           txtNomeCamp.setText(null);
           //txtNomeCamp.setText(null);
            txtEndeCamp.setText(null);
            txtfonecam.setText(null);
            txtCpfCamp.setText(null);
            TxtPlaca.setText(null);
            jObervacoes.setText(null);
        
        }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,e);
    }
    

        }   
        
        private void PesquisarCampistas(){
    String sql = " select * from tbcampista where nomecamp like ?";
    try {
        pst=conexao.prepareStatement(sql);
        // Passando da caixa de pesquisa
        pst.setString(1, txtPesquisarCamp.getText()+ "%");
        // executa a query
        rs=pst.executeQuery();
        // usa a biblioteca para preencher a tabela
        tblCampista.setModel(DbUtils.resultSetToTableModel(rs));
     
        
        
        
    } catch (Exception e) {
        JOptionPane.showInternalMessageDialog(null, e);
    }

}
        //  setar campos do formulario campo da tabela
    public void setar_campos(){
    
     int setar = tblCampista.getSelectedRow();
     idCamp.setText(tblCampista.getModel().getValueAt(setar,0).toString());
     txtNomeCamp.setText(tblCampista.getModel().getValueAt(setar,1).toString());
     txtEndeCamp.setText(tblCampista.getModel().getValueAt(setar,2).toString());
    txtfonecam.setText(tblCampista.getModel().getValueAt(setar,3).toString());
    txtCpfCamp.setText(tblCampista.getModel().getValueAt(setar,4).toString());
    TxtPlaca.setText(tblCampista.getModel().getValueAt(setar,5).toString());
    jObervacoes.setText(tblCampista.getModel().getValueAt(setar,6).toString());
    BtnCadastroCamp.setEnabled(false);
    
    
    }    
    private void alterar(){
    
String sql="update tbcampista set nomecamp=?,endcamp=?,TelefoneCamp=?,cpfcamp=?,PlacaCamp=?,observacoes=? where idCamp=?";

    try {        
        pst=conexao.prepareStatement(sql);
        pst.setString(1, txtNomeCamp.getText());
        pst.setString(2,txtEndeCamp.getText());
         pst.setString(3, txtfonecam.getText());
         pst.setString(4,txtCpfCamp.getText());
         pst.setString(5,TxtPlaca.getText());
          pst.setString(6,jObervacoes.getText());
         pst.setString(7,idCamp.getText());
          
       if((((txtCpfCamp.getText().isEmpty())||(txtNomeCamp.getText().isEmpty())))){   
            
        JOptionPane.showMessageDialog(null," Todos os Campos Marcados com *, são Obrigatórios");     
        
        }else{
        
        int adicionado = pst.executeUpdate();
        
        if(adicionado > 0){
        JOptionPane.showMessageDialog(null," Dados de Usuario Alterado com Sucesso!!!");
        //idate.setText(null);
          
           txtNomeCamp.setText(null);
            txtEndeCamp.setText(null);
            txtfonecam.setText(null);
            txtCpfCamp.setText(null);
            BtnCadastroCamp.setEnabled(true);
            TxtPlaca.setText(null);
            jObervacoes.setText(null);
        
        }
        }  
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,e);     


    }





}
    private void excluir_campista(){
    
        // remove
        int confirma = JOptionPane.showConfirmDialog(null, "Ter certeza que Deseja Excluir??");
        if (confirma==JOptionPane.YES_OPTION){        
        String sql="delete from tbcampista where idcamp=? ";
        
            try {
                 pst=conexao.prepareStatement(sql);
                 pst.setString(1,idCamp.getText());
                int apagado = pst.executeUpdate();
                 if(apagado>0){
                 
                 JOptionPane.showMessageDialog(null," Campista Removido com Sucesso!!!");
                 
           txtNomeCamp.setText(null);
            txtEndeCamp.setText(null);
            txtfonecam.setText(null);
            txtCpfCamp.setText(null);
             TxtPlaca.setText(null);
              jObervacoes.setText(null);
                 }
            } catch (Exception e) {
                 JOptionPane.showMessageDialog(null,e);     

            }
        }
    
    
    
    
    
    
    
    
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNomeCamp = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtEndeCamp = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtfonecam = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtCpfCamp = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        TxtPlaca = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jObervacoes = new javax.swing.JTextArea();
        BtnCadastroCamp = new javax.swing.JButton();
        txtPesquisarCamp = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCampista = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        idCamp = new javax.swing.JLabel();

        setTitle("Tela Campistas");

        jLabel1.setText("* Obrigatório");

        jLabel2.setText("* Nome");

        jLabel3.setText("Endereço");

        jLabel4.setText("Fone");

        jLabel5.setText("* CPF");

        txtCpfCamp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCpfCampActionPerformed(evt);
            }
        });

        jLabel6.setText("Placa ");

        jLabel7.setText("Observações");

        jObervacoes.setColumns(20);
        jObervacoes.setRows(5);
        jScrollPane1.setViewportView(jObervacoes);

        BtnCadastroCamp.setText("Cadastrar");
        BtnCadastroCamp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCadastroCampActionPerformed(evt);
            }
        });

        txtPesquisarCamp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisarCampActionPerformed(evt);
            }
        });
        txtPesquisarCamp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPesquisarCampKeyReleased(evt);
            }
        });

        jLabel8.setText("Pesquisar");

        tblCampista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblCampista.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCampistaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblCampista);

        jButton1.setText("Alterar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Excluir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        idCamp.setText("ID");
        idCamp.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtPesquisarCamp, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(idCamp)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addComponent(BtnCadastroCamp)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtfonecam, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtNomeCamp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
                                        .addComponent(txtEndeCamp, javax.swing.GroupLayout.Alignment.LEADING)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(67, 67, 67))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addGap(78, 78, 78)
                                        .addComponent(jButton2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtCpfCamp, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(43, 43, 43)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TxtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 515, Short.MAX_VALUE)
                        .addGap(67, 67, 67)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPesquisarCamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel1))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel7)
                        .addGap(9, 9, 9))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(idCamp)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNomeCamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndeCamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtfonecam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtCpfCamp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(TxtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnCadastroCamp)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        setBounds(0, 0, 618, 444);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCpfCampActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCpfCampActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCpfCampActionPerformed

    private void txtPesquisarCampActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisarCampActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisarCampActionPerformed

    private void BtnCadastroCampActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCadastroCampActionPerformed
Adicionar();        // TODO add your handling code here:
    }//GEN-LAST:event_BtnCadastroCampActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
alterar();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
excluir_campista();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtPesquisarCampKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPesquisarCampKeyReleased
        // TODO add your handling code here
        PesquisarCampistas();
    }//GEN-LAST:event_txtPesquisarCampKeyReleased

    private void tblCampistaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCampistaMouseClicked
        // TODO add your handling code here:
        // setar campos
        setar_campos();
    }//GEN-LAST:event_tblCampistaMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCadastroCamp;
    private javax.swing.JTextField TxtPlaca;
    private javax.swing.JLabel idCamp;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextArea jObervacoes;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblCampista;
    private javax.swing.JTextField txtCpfCamp;
    private javax.swing.JTextField txtEndeCamp;
    private javax.swing.JTextField txtNomeCamp;
    private javax.swing.JTextField txtPesquisarCamp;
    private javax.swing.JTextField txtfonecam;
    // End of variables declaration//GEN-END:variables
}
